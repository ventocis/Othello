import org.junit.Test;

public class MainTest {

    @Test
    public void testMain(){
        String [] testingArgumentList = { "testOne", "testTwo", "testThree" };
        Main.main(testingArgumentList);
    }
}
