
public class AI {

}
