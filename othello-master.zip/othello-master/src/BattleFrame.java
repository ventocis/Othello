/**
 * 
 * @author Owner
 *This is a class to hold the BattleShip panel design.
 */
public class BattleFrame {

}
